﻿#!/bin/sh
dotnet /usr/share/Calcpad/Calcpad.dll $1 $2 $3